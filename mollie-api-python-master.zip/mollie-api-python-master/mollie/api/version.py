# In this file the version of the package is defined.

# Don't change the syntax of the definition unless you know what you're doing, because this file is
# processed by python imports and by regular expressions. The version is defined as a string in the
# regular semantic versioning scheme (major,minor,patch).

VERSION = '2.0.6'
