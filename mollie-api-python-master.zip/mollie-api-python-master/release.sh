#!/bin/sh
python setup.py sdist upload
